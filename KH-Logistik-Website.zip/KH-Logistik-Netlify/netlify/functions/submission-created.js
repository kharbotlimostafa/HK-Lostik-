/* Netlify runs this function automatically after every verified form submission.
   It forwards the application to a Telegram chat.
   The bot token and chat id live ONLY in Netlify "Environment variables" (never in this code):
     TELEGRAM_BOT_TOKEN   token from @BotFather
     TELEGRAM_CHAT_ID     id of the chat or group that should receive the applications */

const esc = (s) => String(s == null ? '' : s).slice(0, 500).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const list = (v) => (Array.isArray(v) ? v.join(', ') : v);
const EXP = { none: 'keine', lt1: 'unter 1 Jahr', gt1: 'über 1 Jahr' };
const LIC = { yes: 'ja', no: 'nein' };

async function telegram(token, method, body) {
  const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, body instanceof FormData
    ? { method: 'POST', body }
    : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  if (!res.ok) throw new Error(`Telegram ${method} failed: ${res.status} ${await res.text()}`);
}

exports.handler = async (event) => {
  const token = process.env.TELEGRAM_BOT_TOKEN, chat = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chat) return { statusCode: 200, body: 'Telegram is not configured (set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID).' };

  const payload = JSON.parse(event.body || '{}').payload || {};
  if (payload.form_name !== 'bewerbung') return { statusCode: 200, body: 'ignored' };
  const d = payload.data || {};

  const lines = [
    '📨 <b>Neue Bewerbung</b>',
    '',
    `👤 <b>${esc(d.name)}</b>`,
    `📞 ${esc(d.phone)}`,
    d.email ? `✉️ ${esc(d.email)}` : null,
    `📍 ${esc(d.city)}`,
    '',
    `🚗 Führerschein B: ${esc(LIC[d.license] || d.license)}`,
    `🧰 Erfahrung: ${esc(EXP[d.exp] || d.exp)}`,
    d.lang ? `🗣 Sprachen: ${esc(list(d.lang))}` : null,
    d.start ? `🗓 Start: ${esc(d.start)}` : null,
    d.ui_lang ? `🌐 Website-Sprache: ${esc(String(d.ui_lang).toUpperCase())}` : null
  ].filter((x) => x !== null);

  try {
    await telegram(token, 'sendMessage', { chat_id: chat, text: lines.join('\n'), parse_mode: 'HTML', disable_web_page_preview: true });

    // optional CV: download it from Netlify and pass it on as a document
    const cv = d.cv;
    const url = cv && (typeof cv === 'string' ? cv : cv.url);
    if (url) {
      const file = await fetch(url);
      if (file.ok) {
        const form = new FormData();
        form.append('chat_id', chat);
        form.append('caption', `Lebenslauf: ${String(d.name || '').slice(0, 100)}`);
        form.append('document', new Blob([await file.arrayBuffer()]), (cv && cv.filename) || 'lebenslauf');
        await telegram(token, 'sendDocument', form);
      }
    }
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: 'Telegram error (see function log)' };
  }
  return { statusCode: 200, body: 'ok' };
};
